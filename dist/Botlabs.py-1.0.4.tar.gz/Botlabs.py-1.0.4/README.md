![Version](https://img.shields.io/pypi/v/Botlabs.py) ![Requirements](https://img.shields.io/pypi/pyversions/Botlabs.py) ![Has wheel](https://img.shields.io/pypi/wheel/Botlabs.py) ![Docs website up](https://img.shields.io/website?down_color=red&down_message=Docs%20down&up_color=blue&up_message=Docs%20up&url=https%3A%2F%2Fpjotr07740.github.io%2Fbotlabs.py%2F) ![Contributors](https://img.shields.io/github/contributors/pjotr07740/botlabs.py) ![Last commit](https://img.shields.io/github/last-commit/pjotr07740/Botlabs.py) ![Live](https://img.shields.io/twitch/status/pjotr0707) ![Stable](https://img.shields.io/pypi/status/Botlabs.py) ![Discord](https://img.shields.io/discord/715558840959238154)

# botlabs.py
### About
botlabs.py is an API wrapper for discordlabs.org.

### Documentation
https://pjotr07740.github.io/botlabs.py/

### Install
```
pip install Botlabs.py
```
